<?php
session_start();
$conn = new mysqli("localhost", "root", "", "digital_complain_system");

if (!isset($_SESSION['id'])) {
    echo "<script>alert('Please log in to vote.'); window.location.href='signin.php';</script>";
    exit();
}

$user_id = $_SESSION['id'];

// Fetch latest poll
$poll = $conn->query("SELECT * FROM polls ORDER BY id DESC LIMIT 1")->fetch_assoc();

if (!$poll) {
    echo "<script>alert('No active polls available.'); window.location.href='client_dashboard.php';</script>";
    exit();
}

$poll_id = $poll['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['option_id'])) {
    $option_id = $_POST['option_id'];

    // Check if already voted
    $check_vote = $conn->prepare("SELECT * FROM votes WHERE user_id = ? AND poll_id = ?");
    $check_vote->bind_param("ii", $user_id, $poll_id);
    $check_vote->execute();
    $vote_result = $check_vote->get_result();

    if ($vote_result->num_rows > 0) {
        echo "<script>alert('You have already voted in this poll.'); window.location.href='client_dashboard.php';</script>";
        exit();
    }

    // Increment vote and log user vote
    $conn->query("UPDATE poll_options SET votes = votes + 1 WHERE id = $option_id");

    $stmt = $conn->prepare("INSERT INTO votes (user_id, poll_id, voted_at) VALUES (?, ?, NOW())");
    $stmt->bind_param("ii", $user_id, $poll_id);
    $stmt->execute();

    echo "<script>alert('Vote submitted!'); window.location.href='client_dashboard.php';</script>";
    exit();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Vote in Poll</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap" rel="stylesheet">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Poppins', sans-serif;
    }
    body {
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      background: #6665ee;
    }
    .wrapper {
      background: #fff;
      border-radius: 15px;
      padding: 25px;
      max-width: 400px;
      width: 100%;
      box-shadow: 0px 5px 10px rgba(0,0,0,0.1);
    }
    .wrapper header {
      font-size: 22px;
      font-weight: 600;
      margin-bottom: 20px;
      text-align: center;
    }
    form label {
      display: block;
      margin-bottom: 12px;
      padding: 10px 15px;
      border: 2px solid #e6e6e6;
      border-radius: 8px;
      transition: all 0.3s ease;
      cursor: pointer;
    }
    form label:hover {
      border-color: #ccc;
      background-color: #f9f9f9;
    }
    input[type="radio"] {
      margin-right: 10px;
    }
    button {
      width: 100%;
      background: #6665ee;
      color: #fff;
      padding: 10px 0;
      font-size: 16px;
      font-weight: 500;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      transition: background 0.3s ease;
    }
    button:hover {
      background: #5756d6;
    }
  </style>
</head>
<body>

  <div class="wrapper">
    <header><?php echo $poll['question']; ?></header>
    <form method="post">
      <?php 
      $options = $conn->query("SELECT * FROM poll_options WHERE poll_id = {$poll['id']}");
      while ($opt = $options->fetch_assoc()): ?>
        <label>
          <input type="radio" name="option_id" value="<?= $opt['id'] ?>" required>
          <?= htmlspecialchars($opt['option_text']) ?>
        </label>
      <?php endwhile; ?>
      <br>
      <button type="submit">Submit Vote</button>
    </form>
  </div>

</body>
</html>
