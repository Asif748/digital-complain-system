<?php
session_start();
include 'dbconnect.php';

if (!isset($_SESSION['id'])) {
    echo "Please log in. Click <a href='./signin.php'>Log in</a>";
    exit();
}

$id = $_SESSION['id'];

$sql = "SELECT ID, Username, Password, Name, Address, Age, Phone_Number,SSN, user_type FROM users WHERE ID = '$id'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $userData = $result->fetch_assoc();
} else {
    echo "No data found for the current user.";
    exit();
}

// $sql_fines = "SELECT fine_id, start_time, end_time, violation, taka FROM fines WHERE UID = '$uid'";
// $fines_result = $conn->query($sql_fines);

// $sql_toll = "SELECT toll_id, Time, payment, booth_no FROM toll_pay WHERE UID = '$uid'";
// $toll_result = $conn->query($sql_toll);

if (isset($_POST['signout'])) {
    session_unset();
    session_destroy();
    header("Location: ./index.html");
    exit();
}
