
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Client Dashboard</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            box-sizing: border-box;
        }

        body {
            background: #f5f6fa;
            color: #2f3640;
        }

        .navbar {
            background-color: #2e86de;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .navbar h2 {
            margin: 0;
        }

        .container {
            padding: 30px;
        }

        .welcome {
            margin-bottom: 30px;
            font-size: 1.2em;
        }

        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
        }

        .card {
            background: white;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            text-align: center;
            transition: transform 0.3s ease;
        }

        .card:hover {
            transform: scale(1.05);
        }

        .card h3 {
            margin-bottom: 15px;
            color: #2e86de;
        }

        .card p {
            margin-bottom: 20px;
            font-size: 14px;
        }

        .card a {
            text-decoration: none;
            background-color: #2e86de;
            color: white;
            padding: 10px 15px;
            border-radius: 8px;
            font-weight: bold;
        }

        .card a:hover {
            background-color: #1b4f72;
        }

        .footer {
            margin-top: 50px;
            text-align: center;
            font-size: 0.9em;
            color: gray;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <h2>Client Dashboard</h2>
        <a href="index.html" style="color:white; text-decoration:none;">Sign Out</a>
    </div>

    <div class="container">
        <div class="welcome">
            <p>Welcome, <strong>eikhane database theke username fetch kore bosaite hbe
            </strong> 👋</p>
            <p>Here's what you can do today:</p>
        </div>

        <div class="grid">
            <div class="card">
                <h3>🗳 Vote on Poll</h3>
                <p>Participate in community polls to share your opinion.</p>
                <a href="voteonpoll.php">Vote Now</a>
            </div>

            <div class="card">
                <h3>📨 Submit a Complaint</h3>
                <p>Report any issues or concerns anonymously.</p>
                <a href="complain.php">Submit</a>
            </div>

            <div class="card">
                <h3>📊 Complaint Status</h3>
                <p>Check the progress of your submitted complaints.</p>
                <a href="complain.php">Track</a>
            </div>

            <div class="card">
                <h3>🧑‍💼 Personal Info</h3>
                <p>Update your profile and contact details.</p>
                <a href="profile.php">Manage</a>
            </div>
        </div>
    </div>

    <div class="footer">
        <p>&copy; 2025 Municipality Portal | Empowering Citizens</p>
    </div>
</body>
</html>
