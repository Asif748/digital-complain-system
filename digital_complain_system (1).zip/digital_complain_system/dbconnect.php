<?php

$id = 'ID';
$Username = 'Username';
$pass = 'Password';
$name = 'Name';
$Age = 'Age';
$phone_no = 'Phone_Number';
$ssn = 'SSN';
$email = 'Email';
$address = 'Address';
$UserType = 'UserType';


//create connection
$conn = new mysqli("localhost", "root", "", "digital_complain_system");
#if($conn->connect_error){
#	echo "Not connected";
#}
#else{
#	echo "Connected";
#}
