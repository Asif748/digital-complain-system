<?php
session_start();
include "dbconnect.php";

if (isset($_POST['signin'])) {
    $id = $conn->real_escape_string($_POST['id']);
    $pass = $conn->real_escape_string($_POST['pass']);


    if (empty($id) || empty($pass)) {
        echo "User ID or Password cannot be empty.";
        exit();
    }

    $sql = "SELECT * FROM users WHERE ID='$id' AND Password='$pass'";
    $result = $conn->query($sql);

    if (!$result) {
        echo "Error: ";
        exit();
    }

    if ($result->num_rows == 0) {
        echo "<script>alert('Wrong Username or Password');window.location.href='./signin.php';</script>";
        exit();
    } else {
        $user = $result->fetch_assoc();

        $_SESSION['id'] = $user['ID'];
        $_SESSION['name'] = $user['Name'];
        $_SESSION['user_type'] = $user['UserType'];


        if ($user['UserType'] === 'admin') {
            header("Location: ./admin.php");
        } elseif ($user['UserType'] === 'client') {
            header("Location: ./client.php");
        } else {
            echo "Invalid user type.";
            exit();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url(images/Padma_Bridge.jpg);
            background-color: #333;
            background-size: cover;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            overflow: hidden;
        }

        .container {
            margin: 0 auto;
            padding: 2em;
            width: 300px;
            background-color: white;
            border-radius: 10px;
            position: relative;
        }

        @property --angle {
            syntax: "<angle>";
            initial-value: 0deg;
            inherits: false;
        }

        .container::after,
        .container::before {
            content: '';
            position: absolute;
            height: 100%;
            width: 100%;
            background-image: conic-gradient(from var(--angle), #ff4545, #00ff99, #006aff, #ff0095, #ff4545);
            top: 50%;
            left: 50%;
            translate: -50% -50%;
            z-index: -1;
            padding: 3px;
            border-radius: 10px;
            animation: 3s spin linear infinite;
        }

        .container::before {
            filter: blur(1.5rem);
            opacity: 0.5;
        }

        @keyframes spin {
            from {
                --angle: 0deg;
            }

            to {
                --angle: 360deg;
            }
        }





        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        .input-group {
            margin-bottom: 15px;
        }

        .input-group label {
            display: block;
            margin-bottom: 5px;
            color: #333;
        }

        .input-group input {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }

        .show-password-container {
            display: flex;
            align-items: center;
            margin-top: 10px;
        }

        .show-password-container input[type="checkbox"] {
            margin-right: 8px;
        }

        .button {
            width: 100%;
            padding: 10px;
            background-color: #28a745;
            border: none;
            border-radius: 5px;
            color: white;
            font-size: 16px;
            cursor: pointer;
            margin-top: 10px;
        }

        .button:hover {
            background-color: #218838;
        }

        .footer {
            margin-top: 15px;
            text-align: center;
            color: #666;
            font-size: 14px;
        }

        .footer a {
            color: #007bff;
            text-decoration: none;
        }

        .footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>
    <div class="container">
        <h2>Sign In</h2>
        <form method="post" action="signin.php">
            <div class="input-group">
                <label for="id">User ID</label>
                <input type="text" id="id" name="id" placeholder="Enter your User ID" required>
            </div>
            <div class="input-group">
                <label for="pass">Password</label>
                <input type="password" id="pass" name="pass" placeholder="Enter your password" required>
            </div>
            <div class="show-password-container">
                <input type="checkbox" id="showPassword" onclick="togglePasswordVisibility()">
                <label for="showPassword">Show Password</label>
            </div>
            <button type="submit" class="button" name="signin">Sign In</button>
        </form>
        <div class="footer">
            <p>Don't have an account? <a href="signup.php">Sign Up</a></p>
            <p>Go to <a href="./index.html">Home</a></p>
        </div>
    </div>

    <script>
        function togglePasswordVisibility() {
            const passwordInput = document.getElementById('pass');
            const showPasswordCheckbox = document.getElementById('showPassword');

            if (showPasswordCheckbox.checked) {
                passwordInput.type = 'text';
            } else {
                passwordInput.type = 'password';
            }
        }
    </script>
</body>

</html>