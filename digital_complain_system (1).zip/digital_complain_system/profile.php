<?php
session_start();
include("db_connection.php"); // Ensure the database connection is included

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id']; // Get the user ID from the session
$message = "";

// Handle profile update when the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize input data
    $name = $_POST["name"];
    $address = $_POST["address"];
    $age = $_POST["age"];
    $phone = $_POST["phone"];
    $ssn = $_POST["ssn"];

    // Update query to modify the existing user's details
    $sql = "UPDATE users SET Name=?, Address=?, Age=?, Phone_Number=?, SSN=? WHERE ID=?";
    
    if ($stmt = $conn->prepare($sql)) {
        // Bind parameters (Name, Address, Age, Phone, SSN, User ID)
        $stmt->bind_param("ssisss", $name, $address, $age, $phone, $ssn, $user_id);
        
        // Execute query to update user data
        if ($stmt->execute()) {
            $message = "Profile updated successfully!";
        } else {
            $message = "Update failed: " . $stmt->error;
        }
        $stmt->close();
    } else {
        $message = "Failed to prepare statement: " . $conn->error;
    }
}

// Fetch current user data to pre-populate the form
$sql = "SELECT Name, Address, Age, Phone_Number, SSN FROM users WHERE ID=?";
if ($stmt = $conn->prepare($sql)) {
    $stmt->bind_param("i", $user_id);  // Bind user_id as integer
    $stmt->execute();
    $stmt->bind_result($name, $address, $age, $phone, $ssn);
    
    if (!$stmt->fetch()) {
        // If no user found, redirect to login or show error
        header("Location: login.php");
        exit();
    }
    $stmt->close();
} else {
    echo "Failed to prepare select statement: " . $conn->error;
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Profile</title>
    <style>
        body {
            font-family: Arial;
            background-color: #f1f1f1;
        }
        .container {
            background: #fff;
            max-width: 500px;
            margin: 50px auto;
            padding: 30px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            border-radius: 12px;
        }
        h2 {
            color: #2e86de;
            text-align: center;
        }
        label {
            display: block;
            margin-top: 15px;
        }
        input {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border-radius: 8px;
            border: 1px solid #ccc;
        }
        button {
            background: #2e86de;
            color: white;
            padding: 12px;
            border: none;
            width: 100%;
            border-radius: 8px;
            margin-top: 20px;
            cursor: pointer;
            font-weight: bold;
        }
        .message {
            color: green;
            text-align: center;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Manage Profile</h2>
    <?php if ($message) echo "<p class='message'>" . htmlspecialchars($message) . "</p>"; ?>
    <form method="post">
        <label>Name</label>
        <input type="text" name="name" value="<?= htmlspecialchars($name) ?>" required>

        <label>Address</label>
        <input type="text" name="address" value="<?= htmlspecialchars($address) ?>" required>

        <label>Age</label>
        <input type="number" name="age" value="<?= htmlspecialchars($age) ?>" required>

        <label>Phone Number</label>
        <input type="text" name="phone" value="<?= htmlspecialchars($phone) ?>" required>

        <label>SSN</label>
        <input type="text" name="ssn" value="<?= htmlspecialchars($ssn) ?>" required>

        <button type="submit">Update Info</button>
    </form>
</div>

</body>
</html>
