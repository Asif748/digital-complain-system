<?php
session_start();
if (isset($_POST['signup'])) {
    include 'dbconnect.php';

    $UserType = $_POST['UserType'];
    $user_name = $_POST['user_name'];
    $id = $_POST['id'];
    $pass = $_POST['pass'];
    $name = $_POST['name'];
    $phone_no = $_POST['phone_no'];
    $age = $_POST['age'];
    $SSN = $_POST['SSN'];
    $address = $_POST['address'];

    if ($UserType === 'Admin' && $_POST['security_key'] !== '123') {
        echo "<script>alert('❌ Incorrect Security Key for Admin.');</script>";
    } else {
        $sql = "INSERT INTO users (ID, Username, Password, Name, Address, Age, Phone_Number, SSN , UserType) 
                VALUES ('$id', '$user_name', '$pass', '$name', '$address', '$age', '$phone_no', '$SSN', '$UserType')";

        if ($conn->query($sql) === TRUE) {
            echo "<p>New user created. You can <a href='./signin.php'>Sign in</a> now.</p>";
            exit();
        } else {
            echo "<p>Error: User not created. " . $conn->error . "</p>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sign Up</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url(images/Padma_Bridge.jpg);
            background-size: cover;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .container {
            margin-top: 20px;
            margin-bottom: 20px;
            padding: 2em;
            width: 320px;
            background-color: white;
            border-radius: 10px;
            position: relative;
        }

        @property --angle {
            syntax: "<angle>";
            initial-value: 0deg;
            inherits: false;
        }

        .container::after,
        .container::before {
            content: '';
            position: absolute;
            height: 100%;
            width: 100%;
            background-image: conic-gradient(from var(--angle), #ff4545, #00ff99, #006aff, #ff0095, #ff4545);
            top: 50%;
            left: 50%;
            translate: -50% -50%;
            z-index: -1;
            padding: 3px;
            border-radius: 10px;
            animation: 3s spin linear infinite;
        }

        .container::before {
            filter: blur(1.5rem);
            opacity: 0.5;
        }

        @keyframes spin {
            from { --angle: 0deg; }
            to { --angle: 360deg; }
        }

        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        .input-group {
            margin-bottom: 15px;
        }

        .input-group label {
            display: block;
            margin-bottom: 5px;
            color: #333;
        }

        .input-group input,
        .input-group select {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }

        .button {
            width: 100%;
            padding: 10px;
            background-color: #28a745;
            border: none;
            border-radius: 5px;
            color: white;
            font-size: 16px;
            cursor: pointer;
            margin-top: 10px;
        }

        .button:hover {
            background-color: #218838;
        }

        .footer {
            margin-top: 15px;
            text-align: center;
            color: #666;
            font-size: 14px;
        }

        .footer a {
            color: #007bff;
            text-decoration: none;
        }

        .footer a:hover {
            text-decoration: underline;
        }

        #securityKeyGroup {
            display: none;
        }
    </style>

    <!-- ✅ Show/hide security key input -->
    <script>
        function handleUserTypeChange(value) {
            const securityField = document.getElementById('securityKeyGroup');
            if (value === 'Admin') {
                securityField.style.display = 'block';
            } else {
                securityField.style.display = 'none';
            }
        }
    </script>
</head>

<body>
    <div class="container">
        <h2>Create an Account</h2>
        <form method="post" action="signup.php">
            <div class="input-group">
                <label for="id">User ID</label>
                <input type="text" id="id" name="id" placeholder="Enter your User ID" required>
            </div>
            <div class="input-group">
                <label for="pass">Password</label>
                <input type="password" id="pass" name="pass" placeholder="Enter your password" required>
            </div>
            <div class="input-group">
                <label for="name">Name</label>
                <input type="text" id="name" name="name" placeholder="Enter your name" required>
            </div>
            <div class="input-group">
                <label for="user_name">Username</label>
                <input type="text" id="user_name" name="user_name" placeholder="Enter your username" required>
            </div>
            <div class="input-group">
                <label for="address">Address</label>
                <input type="text" id="address" name="address" placeholder="Enter your address" required>
            </div>
            <div class="input-group">
                <label for="age">Age</label>
                <input type="number" id="age" name="age" required>
            </div>
            <div class="input-group">
                <label for="phone_no">Phone Number</label>
                <input type="number" id="phone_no" name="phone_no" placeholder="Enter your phone number" required>
            </div>
            <div class="input-group">
                <label for="SSN">SSN</label>
                <input type="number" id="SSN" name="SSN" placeholder="Enter your SSN number" required>
            </div>
            <div class="input-group">
                <label for="UserType">User Type:</label>
                <select id="UserType" name="UserType" onchange="handleUserTypeChange(this.value)" required>
                    <option value="" disabled selected>Select User Type</option>
                    <option value="Admin">Admin</option>
                    <option value="Client">Client</option>
                </select>
            </div>

            <!-- ✅ Hidden by default: Security key input -->
            <div class="input-group" id="securityKeyGroup">
                <label for="security_key">Security Key</label>
                <input type="password" id="security_key" name="security_key" placeholder="Enter Admin Security Key">
            </div>

            <button type="submit" class="button" name="signup">Sign Up</button>
        </form>

        <div class="footer">
            <p>Already have an account? <a href="./signin.php">Sign In</a></p>
            <p>Go to <a href="./index.html">Home</a></p>
        </div>
    </div>
</body>
</html>
