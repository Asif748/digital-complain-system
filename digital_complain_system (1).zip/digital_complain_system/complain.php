<?php
include 'dbconnect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $category = $_POST['category'];
    $complain = $_POST['complain'];
    $mediaPaths = []; // Array to hold the paths of uploaded media
    $totalSize = 0; // To track the total size of uploaded files

    // Sanitize inputs
    $category = mysqli_real_escape_string($conn, $category);
    $complain = mysqli_real_escape_string($conn, $complain);

    // Handle file uploads
    if (isset($_FILES['media']) && count($_FILES['media']['name']) > 0) {
        $mediaFiles = $_FILES['media'];

        // Check if the number of files is 5 or less
        if (count($mediaFiles['name']) <= 5) {
            // Loop through the files
            for ($i = 0; $i < count($mediaFiles['name']); $i++) {
                $fileName = $mediaFiles['name'][$i];
                $fileTmp = $mediaFiles['tmp_name'][$i];
                $fileError = $mediaFiles['error'][$i];
                $fileSize = $mediaFiles['size'][$i];

                // Check if file uploaded successfully
                if ($fileError === 0) {
                    // Check if the file size exceeds the limit
                    if ($totalSize + $fileSize <= 500 * 1024 * 1024) { // 500 MB limit
                        // Generate a unique file name
                        $fileExt = pathinfo($fileName, PATHINFO_EXTENSION);
                        $newFileName = uniqid('', true) . '.' . $fileExt;
                        $fileDestination = 'uploads/' . $newFileName;

                        // Move the file to the uploads folder
                        if (move_uploaded_file($fileTmp, $fileDestination)) {
                            // Add the file path to the array
                            $mediaPaths[] = $fileDestination;
                            // Update total size
                            $totalSize += $fileSize;
                        }
                    } else {
                        echo "<script>
                                alert('Total file size exceeds 500 MB. Please upload smaller files.');
                                window.location.href = 'complain.php';
                              </script>";
                        exit;
                    }
                }
            }
        } else {
            echo "<script>
                    alert('You can upload a maximum of 5 files.');
                    window.location.href = 'complain.php';
                  </script>";
            exit;
        }
    }

    // Store the complaint and media paths in the database
    $mediaPathsStr = implode(',', $mediaPaths); // Convert array to comma-separated string
    $sql = "INSERT INTO anonymus (category, complain, media_path) VALUES ('$category', '$complain', '$mediaPathsStr')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>
                alert('Complaint submitted successfully. Thank you!');
                window.location.href = 'index.html';
              </script>";
    } else {
        echo "<script>
                alert('Error: Could not submit complaint. Please try again.');
                window.location.href = 'complain.php';
              </script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complaint Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url(images/Padma_Bridge.jpg);
            background-size: cover;
            background-color: #333;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            overflow: auto;
        }

        .container {
            margin: 0 auto;
            margin-top: 20px;
            margin-bottom: 20px;
            padding: 2em;
            width: auto;
            background-color: white;
            border-radius: 10px;
            position: relative;
        }

        .form {
            margin-top: 20px;
        }

        .select {
            border-radius: 10px;
            padding: 10px;
            margin-bottom: 20px;
        }

        .text {
            border: 2px dashed teal;
            border-radius: 10px;
            padding: 10px;
        }

        .btn {
            border: 2px solid black;
            border-radius: 10px;
            padding: 10px;
            margin: 5px;
            font-weight: 500;
            background-color: #4681f4;
            color: white;
            margin-top: 20px;
        }

        button:hover {
            background-color: blue;
        }
    </style>
</head>
<body>
    <main class="container">
        <div>
            <p><b>User Name:</b> Anonymus</p>
        </div>
        <form class="form" action="complain.php" method="POST" enctype="multipart/form-data">
            <select required class="select" name="category">
                <option value="select">Select a category</option>
                <option value="Garbage Collection Issues">Garbage Collection Issues</option>
                <option value="Water Supply Problems">Water Supply Problems</option>
                <option value="Electricity Outage or Faults">Electricity Outage or Faults</option>
                <option value="Road Damage or Potholes">Road Damage or Potholes</option>
                <option value="Street Light Not Working">Street Light Not Working</option>
                <option value="Sewage or Drainage Problems">Sewage or Drainage Problems</option>
                <option value="Illegal Construction">Illegal Construction</option>
                <option value="Noise Pollution">Noise Pollution</option>
                <option value="Air Pollution">Air Pollution</option>
                <option value="Encroachment on Public Property">Encroachment on Public Property</option>
                <option value="Stray Animals Issues">Stray Animals Issues</option>
                <option value="Traffic Congestion">Traffic Congestion</option>
                <option value="Bribery Allegations">Bribery Allegations</option>
                <option value="Public Toilet Maintenance">Public Toilet Maintenance</option>
                <option value="Lack of Cleanliness in Public Places">Lack of Cleanliness in Public Places</option>
                <option value="Tree Cutting or Green Space Damage">Tree Cutting or Green Space Damage</option>
                <option value="Harassment">Harassment</option>
                <option value="Uncollected Dead Animals">Uncollected Dead Animals</option>
                <option value="Flooding During Rain">Flooding During Rain</option>
                <option value="Delay in Service Delivery">Delay in Service Delivery</option>
            </select>
            <br>
            <textarea required name="complain" placeholder="Write Your Complaint" class="text" rows="10" cols="50"></textarea>
            <br>

            <label><b>Attach Media (You can upload up to 5 files, total size max 500 MB):</b></label><br>
            <input type="file" name="media[]" accept="image/*,video/*,audio/*" multiple>
            <br><br>

            <button type="submit" class="btn">Submit</button>
        </form>
    </main>
</body>
</html>
