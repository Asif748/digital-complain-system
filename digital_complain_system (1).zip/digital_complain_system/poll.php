<?php
$conn = new mysqli("localhost", "root", "", "digital_complain_system");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $question = $_POST['question'];
    $options = $_POST['options'];

    $conn->query("INSERT INTO polls (question) VALUES ('$question')");
    $poll_id = $conn->insert_id;

    foreach ($options as $opt) {
        if (!empty(trim($opt))) {
            $opt = $conn->real_escape_string($opt);
            $conn->query("INSERT INTO poll_options (poll_id, option_text) VALUES ($poll_id, '$opt')");
        }
    }

    echo "<script>alert('Poll created successfully'); window.location.href='admin_dashboard.php';</script>";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Create a Poll</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Poppins', sans-serif;
    }

    body {
      background: #6665ee;
      padding: 40px 20px;
      display: flex;
      flex-direction: column;
      align-items: center;
    }

    .wrapper, .results-box {
      background: #fff;
      border-radius: 15px;
      padding: 25px;
      width: 100%;
      max-width: 600px;
      box-shadow: 0px 5px 15px rgba(0,0,0,0.1);
      margin-bottom: 40px;
    }

    header, h2 {
      text-align: center;
      font-size: 24px;
      font-weight: 600;
      margin-bottom: 20px;
      color: #333;
    }

    form input[type="text"] {
      width: 100%;
      padding: 10px 15px;
      margin-bottom: 15px;
      border: 2px solid #e6e6e6;
      border-radius: 8px;
      font-size: 15px;
      transition: border 0.3s ease;
    }

    form input[type="text"]:focus {
      border-color: #6665ee;
      outline: none;
    }

    .poll-area label {
      display: block;
      margin-bottom: 10px;
    }

    .poll-area input {
      padding: 8px 15px;
      border: 2px solid #e6e6e6;
      border-radius: 8px;
      width: 100%;
      transition: all 0.2s ease;
    }

    .poll-area input:hover {
      border-color: #ccc;
    }

    button {
      width: 100%;
      background: #6665ee;
      color: #fff;
      padding: 10px 0;
      font-size: 16px;
      font-weight: 500;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      transition: background 0.3s ease;
    }

    button:hover {
      background: #5756d6;
    }

    .poll-block {
      margin-bottom: 30px;
    }

    .poll-block h3 {
      margin-bottom: 10px;
      color: #444;
    }

    .option-bar {
      background: #eee;
      border-radius: 6px;
      height: 10px;
      overflow: hidden;
      margin-top: 5px;
    }

    .option-fill {
      background: #6665ee;
      height: 100%;
    }

    .vote-info {
      display: flex;
      justify-content: space-between;
      font-size: 14px;
      color: #555;
    }

    .total-votes {
      margin-top: 10px;
      font-style: italic;
      color: #666;
    }

    hr {
      margin: 20px 0;
      border: none;
      border-top: 1px solid #ddd;
    }
  </style>
</head>
<body>

  <div class="wrapper">
    <header>Create a Poll</header>
    <form method="post">
      <input type="text" name="question" placeholder="Enter your poll question" required>

      <div class="poll-area">
        <label><input type="text" name="options[]" placeholder="Option 1" required></label>
        <label><input type="text" name="options[]" placeholder="Option 2" required></label>
        <label><input type="text" name="options[]" placeholder="Option 3"></label>
        <label><input type="text" name="options[]" placeholder="Option 4"></label>
      </div>

      <button type="submit">Create Poll</button>
    </form>
  </div>

  <?php
  $polls = $conn->query("SELECT * FROM polls ORDER BY id DESC");
  if ($polls->num_rows > 0):
  ?>
  <div class="results-box">
    <h2>POLE RESULT</h2>

    <?php while ($poll = $polls->fetch_assoc()):
      $poll_id = $poll['id'];
      $options = $conn->query("SELECT * FROM poll_options WHERE poll_id = $poll_id");

      $total_votes = 0;
      $option_data = [];
      while ($opt = $options->fetch_assoc()) {
        $total_votes += $opt['votes'];
        $option_data[] = $opt;
      }
    ?>

    <div class="poll-block">
      <h3><?= htmlspecialchars($poll['question']) ?></h3>

      <?php foreach ($option_data as $opt):
        $votes = $opt['votes'];
        $percent = $total_votes > 0 ? round(($votes / $total_votes) * 100) : 0;
      ?>
        <div class="vote-info">
          <strong><?= htmlspecialchars($opt['option_text']) ?></strong>
          <span><?= $percent ?>% (<?= $votes ?> votes)</span>
        </div>
        <div class="option-bar">
          <div class="option-fill" style="width: <?= $percent ?>%;"></div>
        </div>
      <?php endforeach; ?>

      <p class="total-votes">Total Votes: <?= $total_votes ?></p>
      <hr>
    </div>

    <?php endwhile; ?>
  </div>
  <?php endif; ?>

</body>
</html>
