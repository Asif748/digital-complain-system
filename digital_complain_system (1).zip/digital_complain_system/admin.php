<?php
// Connect to the database
$conn = new mysqli("localhost", "root", "", "digital_complain_system");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch anonymous complaints
$sql = "SELECT * FROM anonymus";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard - Anonymous Complaints</title>
    <style>
        * {
            font-family: 'Segoe UI', sans-serif;
            box-sizing: border-box;
        }

        body {
            margin: 0;
            background: #f4f6f9;
            color: #2c3e50;
        }

        .navbar {
            background-color: #34495e;
            padding: 15px 30px;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .navbar h1 {
            font-size: 24px;
        }

        .navbar a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            padding: 30px;
        }

        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            margin-bottom: 25px;
        }

        .search-bar {
            display: flex;
            flex-grow: 1;
            gap: 10px;
            max-width: 600px;
        }

        .search-bar input {
            width: 100%;
            padding: 10px;
            border: 2px solid #ccc;
            border-radius: 8px;
        }

        .search-bar button {
            padding: 10px 20px;
            background: #3498db;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }

        .search-bar button:hover {
            background-color: #2980b9;
        }

        .poll-button {
            margin-left: 20px;
        }

        .poll-button a {
            text-decoration: none;
            background-color: #2ecc71;
            color: white;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: bold;
        }

        .poll-button a:hover {
            background-color: #27ae60;
        }

        .complaints-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
        }

        .complaint-box {
            background: white;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: transform 0.3s;
        }

        .complaint-box:hover {
            transform: translateY(-5px);
        }

        .complaint-box h3 {
            margin-top: 0;
            color: #e74c3c;
        }

        .complaint-box p {
            margin: 10px 0;
            font-size: 14px;
        }

        .complaint-box img {
            max-width: 100%;
            border-radius: 10px;
            margin-top: 10px;
        }

        .footer {
            text-align: center;
            padding: 20px;
            color: #888;
            margin-top: 40px;
        }

        @media screen and (max-width: 600px) {
            .top-bar {
                flex-direction: column;
                align-items: stretch;
                gap: 15px;
            }

            .poll-button {
                margin-left: 0;
                text-align: center;
            }
        }
    </style>
    <script>
        function filterComplaints() {
            const search = document.getElementById("search").value.toLowerCase();
            const cards = document.getElementsByClassName("complaint-box");

            for (let card of cards) {
                const category = card.getAttribute("data-category").toLowerCase();
                const complaint = card.getAttribute("data-complain").toLowerCase();
                if (category.includes(search) || complaint.includes(search)) {
                    card.style.display = "block";
                } else {
                    card.style.display = "none";
                }
            }
        }
    </script>
</head>
<body>

<div class="navbar">
    <h1>Admin Dashboard</h1>
    <a href="index.html">Logout</a>
</div>

<div class="container">

    <div class="top-bar">
        <!-- Search and Filter -->
        <div class="search-bar">
            <input type="text" id="search" onkeyup="filterComplaints()" placeholder="Search by category or complaint...">
            <button onclick="filterComplaints()">Filter</button>
        </div>

        <!-- Poll Publish Button -->
        <div class="poll-button">
            <a href="poll.php">📢 Publish a Poll</a>
        </div>
    </div>

    <!-- Complaint Boxes -->
    <div class="complaints-grid">
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<div class='complaint-box' data-category='" . htmlspecialchars($row['category']) . "' data-complain='" . htmlspecialchars($row['complain']) . "'>";
                echo "<h3>📌 " . htmlspecialchars($row['category']) . "</h3>";
                echo "<p><strong>Description:</strong> " . htmlspecialchars($row['complain']) . "</p>";
                if (!empty($row['media_path'])) {
                    echo "<img src='" . htmlspecialchars($row['media_path']) . "' alt='Attached Media'>";
                } else {
                    echo "<p><em>No media attached.</em></p>";
                }
                echo "</div>";
            }
        } else {
            echo "<p>No anonymous complaints found.</p>";
        }
        ?>
    </div>
</div>

<div class="footer">
    <p>&copy; 2025 Municipality Portal | Admin View</p>
</div>

</body>
</html>
